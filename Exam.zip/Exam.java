import java.util.Scanner;
public class Exam {
    public static void main(String[] args) {

        Scanner um = new Scanner(System.in);

        System.out.print("Enter the number of students: ");//User enter the number of students
        int numberOfStudents = um.nextInt();

        int passed = 0;
        int failed = 0;

        for (int i = 1; i < numberOfStudents + 1; i++) {
            System.out.print("Enter result for student " + i + ": ");//User enter an result for students
            int result = um.nextInt();

            if (result == 1) {
                passed++;
            } else if (result == 0) {
                failed++;
            } else {
                System.out.println("Invalid input. Please enter 1 for pass or 0 for fail.");
                i--; 
            }
        }

        System.out.println("\nTotal number of students who passed: " + passed); //Display how many students passed
        System.out.println("Total number of students who failed: " + failed); //DIsplay how many students failed

        if (passed > numberOfStudents / 2) {
            System.out.println("Bonus to instructor"); 
        }

        um.close();
    }
}
