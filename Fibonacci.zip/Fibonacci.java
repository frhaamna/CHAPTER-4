import java.util.Scanner;
public class Fibonacci {
    public static void main(String[] args) {
         Scanner um = new Scanner(System.in);
        

        System.out.print("Enter the number : ");
        int fib = um.nextInt();
        
        // Variables to store the first two Fibonacci numbers
        int num1 = 0, num2 = 1;
        
        System.out.println("Fibonacci " + fib + ": ");
        
        while (num1 <= fib) {
            System.out.print(num1 + " ");
            
            // Calculate the next Fibonacci number
            int nextNum = num1 + num2;
            
            // Update the values
            num1 = num2;
            num2 = nextNum;
        }
        
        um.close();
    }
    }

    
