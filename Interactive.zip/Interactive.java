import java.util.Scanner;

public class Interactive {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        //User enter the number 
        System.out.print("Enter a number to calculate its factorial: ");
        int n = scanner.nextInt();
        int factorial = 1;

        for (int i = 1; i <= n; i++) {
            factorial *= i;
        }
        //Factorial num is display
        System.out.println("Factorial of " + n + " is: " + factorial);
    }
}
