import java.util.Scanner;

public class Mod1 {
    public static void main(String[] args) {
        Scanner um = new Scanner(System.in);
        int choice;

        do {
            // Variable for even and odd numbers
            int sumEven = 0;
            int sumOdd = 0;

            for (int i = 1; i <= 10; i++) {
                if (i % 2 == 0) {
                    // Number is even
                    sumEven += i;
                    System.out.println(i + " is even.");
                } else {
                    // Number is odd
                    sumOdd += i;
                    System.out.println(i + " is odd.");
                }
            }

            // Display the even numbers and odd numbers
            System.out.println("Sum of even numbers: " + sumEven);
            System.out.println("Sum of odd numbers: " + sumOdd);

            // Ask user if they want to continue
            System.out.println("Enter 1 to continue or 2 to exit:");
            choice = um.nextInt();
        } while (choice == 1);

        um.close();
    }
}


