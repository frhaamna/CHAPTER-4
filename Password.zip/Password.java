import java.util.Scanner;
public class Password {
    public static void main(String[] args) {

        Scanner um = new Scanner(System.in);
        String password = "ilikechips";
        int attempts = 5; //Can attempt only 5 times
        
        //Display welcoming to user
        System.out.println("Welcome to Our Website!");
        
        while (attempts > 0) {
            System.out.print("Enter your password: "); //User enter the password
            String inputPassword = um.nextLine();

            if (inputPassword.equals(password)) {
                System.out.println("You've Log In!");//Display as the user have logged in
                break;
            } else {
                attempts--;
                if (attempts > 0) {
                    System.out.println("Incorrect password. Please try again.");
                } else {
                    System.out.println("Incorrect password.You've been locked.");
                }
            }
        }
        um.close();
    }
}

