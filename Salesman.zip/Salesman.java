import java.util.Scanner;

public class Salesman {
    public static void main(String[] args) {

        double baseSalary = 600.00;
        double commissionRate = 0.05;  

       //Display the menu
        System.out.println("Tiramisu Cake : RM 5.00");
        System.out.println("Mango Cake : RM 3.00");
        System.out.println("Red Velvet Cake : RM 2.00");
        System.out.println("Kek Batik : RM 2.00");

        Scanner um = new Scanner(System.in);

        System.out.print("Enter the total sales for the previous week: RM "); //User enter the total sales
        double totalSales = um.nextDouble();

        double commission = totalSales * commissionRate; 
        double totalEarnings = baseSalary + commission;

        System.out.println("Commission earned: RM " + commission); //Comission earned displayed
        System.out.println("Total earnings for the week: RM " + totalEarnings); //Total earnings displayed

        um.close();
    }
}
