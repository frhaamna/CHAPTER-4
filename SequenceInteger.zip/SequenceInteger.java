import java.util.Scanner;
public class SequenceInteger {
    public static void main(String[] args) {

        Scanner um = new Scanner(System.in);
        String choice;

        do {
            int evenCount = 0;
            int oddCount = 0;
            
            //User the number of the sequence
            System.out.print("Enter the number of integers in the sequence: ");
            int n = um.nextInt();

            System.out.println("Enter the sequence of integers:");

            for (int i = 0; i < n; i++) {
                int number = um.nextInt();

                if (number % 2 == 0) { //Modulus 2
                    evenCount++;
                } else {
                    oddCount++;
                }
            }
            
            //The integers number displayed
            System.out.println("Number of even integers: " + evenCount);
            System.out.println("Number of odd integers: " + oddCount);

            // Ask if the user wants to continue
            System.out.print("Do you want to enter another sequence? (yes/no): ");
            choice = um.next();
        } while (choice.equalsIgnoreCase("yes"));
        
        //User exit the program
        System.out.println("Program exited.");
        um.close();
    }
}


